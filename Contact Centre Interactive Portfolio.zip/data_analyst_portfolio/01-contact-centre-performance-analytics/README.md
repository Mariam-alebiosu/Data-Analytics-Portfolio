# Contact Centre Performance Analytics

## Project Overview
An end-to-end SQL and BI portfolio project analysing 12,000 synthetic customer interactions across Voice, Chat and Email.

The project focuses on operational performance, customer experience and avoidable demand while demonstrating how analytical outputs can be translated into an interactive management dashboard.

## Business Questions
1. How efficiently is the contact centre handling demand?
2. Which channels and contact reasons generate the greatest operational pressure?
3. How does waiting time affect CSAT and abandonment?
4. Where is first-contact resolution weakest?
5. Which operational areas should management prioritise?

## Tools
- SQL
- Snowflake-style analytical SQL
- HTML / JavaScript interactive dashboard
- BI dashboard design
- KPI development

## Dashboard
Open:

`dashboard/contact_centre_dashboard.html`

The dashboard behaves like a lightweight Tableau-style analytical application with filters, dynamic KPI cards, tooltips, clickable charts and a drill-down performance table.

## KPIs
- Total contacts
- Customer Satisfaction (CSAT)
- Average Handle Time (AHT)
- Average Speed of Answer / Wait Time (ASA)
- First Contact Resolution (FCR)
- Abandonment Rate
- SLA <= 120 seconds
- Repeat Contact Rate

## Repository Structure
```text
01-contact-centre-performance-analytics/
├── README.md
├── data/
│   ├── contact_centre_interactions.csv
│   └── data_dictionary.csv
├── sql/
│   └── contact_centre_analysis.sql
└── dashboard/
    ├── contact_centre_dashboard.html
    └── dashboard_documentation.md
```

## Data Note
The dataset is fully synthetic. No employer, customer or commercially sensitive information is included.

## Skills Demonstrated
SQL • KPI Design • Customer Analytics • Contact Centre Analytics • BI Dashboarding • Data Storytelling • Root-Cause Analysis • Stakeholder Insight
