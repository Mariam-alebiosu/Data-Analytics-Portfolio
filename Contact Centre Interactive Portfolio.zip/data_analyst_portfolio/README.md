# Data Analyst Portfolio

Business-focused analytics portfolio demonstrating SQL, KPI design, dashboarding and stakeholder insight.

## Project 01 — Contact Centre Performance Analytics
A SQL + interactive BI project covering contact volume, CSAT, AHT, ASA, FCR, abandonment, SLA performance and operational drivers.

**Interactive dashboard:** `01-contact-centre-performance-analytics/dashboard/contact_centre_dashboard.html`

## Portfolio Direction
The portfolio intentionally prioritises SQL and business intelligence over Python-heavy analysis.

### Planned projects
- Customer Satisfaction Driver Analysis
- Airline Commercial Performance Analytics
- Analytics Data Pipeline
- Business Investigation Case Study
